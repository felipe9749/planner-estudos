import { useState, useEffect } from "react";

function buildGoogleCalendarUrl(topic, date) {
  const start = new Date(date);
  const end = new Date(start.getTime() + 60 * 60 * 1000);
  const formatDate = (d) => d.toISOString().replace(/[-:]|\.\d{3}/g, "").slice(0, 15) + "Z";
  const params = new URLSearchParams({
    text: topic,
    dates: `${formatDate(start)}/${formatDate(end)}`,
    details: `Revisar conteúdo: ${topic}`,
  });
  return `https://calendar.google.com/calendar/u/0/r/eventedit?${params.toString()}`;
}

export default function StudyPlanner() {
  const [studyPlan, setStudyPlan] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("studyPlan");
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });
  const [newTopic, setNewTopic] = useState("");
  const [selectedDate, setSelectedDate] = useState(null);
  const [gapiLoaded, setGapiLoaded] = useState(false);
  const [isSignedIn, setIsSignedIn] = useState(false);

  useEffect(() => {
    if (typeof Notification !== "undefined" && Notification.permission !== "granted") {
      Notification.requestPermission();
    }
  }, []);

  useEffect(() => {
    const now = new Date();
    studyPlan.forEach((item) => {
      if (item.date && !item.notified && new Date(item.date).toDateString() === now.toDateString()) {
        if (Notification.permission === "granted") {
          new Notification("Lembrete de Estudo", {
            body: `Hoje é o dia para estudar: ${item.topic}`,
          });
          item.notified = true;
        }
      }
    });
  }, [studyPlan]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("studyPlan", JSON.stringify(studyPlan));
    }
  }, [studyPlan]);

  useEffect(() => {
    const loadGapi = () => {
      const script = document.createElement("script");
      script.src = "https://apis.google.com/js/api.js";
      script.onload = () => {
        window.gapi.load("client:auth2", initClient);
      };
      document.body.appendChild(script);
    };

    const initClient = async () => {
      try {
        await window.gapi.client.init({
          apiKey: "",
          clientId: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID,
          discoveryDocs: ["https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest"],
          scope: "https://www.googleapis.com/auth/calendar.events",
        });
        setGapiLoaded(true);
        setIsSignedIn(window.gapi.auth2.getAuthInstance().isSignedIn.get());
        window.gapi.auth2.getAuthInstance().isSignedIn.listen(setIsSignedIn);
      } catch (error) {
        console.error("Erro ao iniciar GAPI", error);
      }
    };

    loadGapi();
  }, []);

  const handleAuthClick = () => {
    window.gapi.auth2.getAuthInstance().signIn();
  };

  const addTopic = () => {
    if (!newTopic.trim()) return;
    setStudyPlan([
      ...studyPlan,
      {
        topic: newTopic.trim(),
        done: false,
        notes: "",
        feedback: "",
        date: selectedDate ? selectedDate.toISOString() : null,
        notified: false
      }
    ]);
    setNewTopic("");
    setSelectedDate(null);
  };

  const toggleDone = (index) => {
    const updatedPlan = [...studyPlan];
    updatedPlan[index].done = !updatedPlan[index].done;
    setStudyPlan(updatedPlan);
  };

  const updateNotes = (index, value) => {
    const updatedPlan = [...studyPlan];
    updatedPlan[index].notes = value;
    setStudyPlan(updatedPlan);
  };

  const updateFeedback = (index, value) => {
    const updatedPlan = [...studyPlan];
    updatedPlan[index].feedback = value;
    setStudyPlan(updatedPlan);
  };

  const addToGoogleCalendar = async (item) => {
    if (!gapiLoaded || !isSignedIn) {
      alert("Você precisa estar conectado com o Google.");
      return;
    }

    const start = new Date(item.date);
    const end = new Date(start.getTime() + 60 * 60 * 1000);

    try {
      await window.gapi.client.calendar.events.insert({
        calendarId: "primary",
        resource: {
          summary: item.topic,
          description: `Revisar conteúdo: ${item.topic}`,
          start: { dateTime: start.toISOString() },
          end: { dateTime: end.toISOString() },
        },
      });
      alert("Evento adicionado ao Google Calendar!");
    } catch (error) {
      console.error("Erro ao criar evento:", error);
      alert("Erro ao adicionar evento. Veja o console.");
    }
  };

  const completedCount = studyPlan.filter((item) => item.done).length;
  const progress = studyPlan.length ? (completedCount / studyPlan.length) * 100 : 0;

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">Plano de Estudos</h1>

      {!isSignedIn && (
        <button onClick={handleAuthClick} style={{backgroundColor: '#EA4335', color: 'white', padding: '8px 16px', border: 'none', borderRadius: '4px', cursor: 'pointer'}}>
          Conectar com Google
        </button>
      )}

      <div style={{display: 'flex', flexDirection: 'row', gap: '12px', marginTop: '12px'}}>
        <input
          placeholder="Adicionar tópico de estudo"
          value={newTopic}
          onChange={(e) => setNewTopic(e.target.value)}
          style={{flex: 1, padding: '8px', fontSize: '16px'}}
        />
        <button onClick={addTopic} style={{padding: '8px 16px', cursor: 'pointer'}}>Adicionar</button>
      </div>
      <div style={{marginTop: '12px'}}>
        <label>Data planejada:</label>
        <input
          type="date"
          value={selectedDate ? selectedDate.toISOString().slice(0,10) : ''}
          onChange={(e) => setSelectedDate(e.target.value ? new Date(e.target.value) : null)}
          style={{padding: '8px', fontSize: '16px', marginLeft: '8px'}}
        />
      </div>

      <progress value={progress} max="100" style={{width: '100%', height: '16px', marginTop: '12px'}}></progress>
      <p>Progresso: {Math.round(progress)}%</p>

      <div style={{marginTop: '24px', display: 'flex', flexDirection: 'column', gap: '16px'}}>
        {studyPlan.map((item, index) => (
          <div key={index} style={{border: '1px solid #ccc', borderRadius: '6px', padding: '12px'}}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
              <h2 style={{fontWeight: 'bold', textDecoration: item.done ? 'line-through' : 'none'}}>{item.topic}</h2>
              <button onClick={() => toggleDone(index)} style={{cursor: 'pointer'}}>{item.done ? 'Desfazer' : 'Concluir'}</button>
            </div>
            {item.date && (
              <div style={{marginTop: '8px'}}>
                <p>📅 Data planejada: {new Date(item.date).toLocaleDateString()}</p>
                <button onClick={() => addToGoogleCalendar(item)} style={{cursor: 'pointer', marginTop: '4px'}}>Criar evento no Google Calendar</button>
              </div>
            )}
            <textarea
              placeholder="Anotações..."
              value={item.notes}
              onChange={(e) => updateNotes(index, e.target.value)}
              style={{width: '100%', height: '60px', marginTop: '8px'}}
            />
            <textarea
              placeholder="Feedback..."
              value={item.feedback}
              onChange={(e) => updateFeedback(index, e.target.value)}
              style={{width: '100%', height: '60px', marginTop: '8px'}}
            />
          </div>
        ))}
      </div>
    </div>
  );
}